package com.fantasy.Draft;

import com.fantasy.FantasyTeam.FantasyTeam;
import com.fantasy.Player.Player;
import com.fantasy.Player.PlayerState;
import com.fantasy.User.User;

public class DraftLogic {

    public  static void firstPicks(DraftRoom room, User user, Player player){
        if (player == null || user == null || room == null)
            throw new NullPointerException();
        PlayerState state = player.getState();
        if (!room.isPlayerAvailable(player) || !state.equals(PlayerState.NONE))
            throw new IllegalArgumentException();
        FantasyTeam fantasyTeam = (FantasyTeam) user.getFantasyTeam();
        if (fantasyTeam == null)
            throw new NullPointerException();
        fantasyTeam.makePick(player);
        player.setState(PlayerState.IN_USE);
        room.removePlayerFromPlayersPoll(player);
        room.updateTurnHistory(user, player);
    }

    public static void makeTransfer(DraftRoom room, User user, Player playerIn, Player playerOut) {
        if (user == null || room == null || playerIn == null || playerOut == null)
            throw new NullPointerException();
        if (!room.isPlayerAvailable(playerIn))
            throw new IllegalArgumentException();
        FantasyTeam fantasyTeam = (FantasyTeam) user.getFantasyTeam();
        if (fantasyTeam == null)
            throw new NullPointerException();
        if (!fantasyTeam.playerContain(playerOut))
            throw new IllegalArgumentException();
        fantasyTeam.makeTransfer(playerIn,playerOut);
        room.removePlayerFromPlayersPoll(playerIn);
        room.addPlayerToPlayersPoll(playerOut);
        room.updateTurnHistory(user, playerIn);
    }
}
