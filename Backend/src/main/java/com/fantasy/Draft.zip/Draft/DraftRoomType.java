package com.fantasy.Draft;

public enum DraftRoomType {
    INITIAL,
    WEEKLY
}
