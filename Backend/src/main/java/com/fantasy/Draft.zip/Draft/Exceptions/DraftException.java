package com.fantasy.Draft.Exceptions;

public class DraftException extends RuntimeException {
    public DraftException(String message) {
        super(message);
    }
}
