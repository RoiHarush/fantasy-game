package com.fantasy.Intefaces;

import com.fantasy.Player.Player;

public interface ICaptain {
    void setCaptain(Player captain);
    void setViceCaptain(Player viceCaptain);
}
