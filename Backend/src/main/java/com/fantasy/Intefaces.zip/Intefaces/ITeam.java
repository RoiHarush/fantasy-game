package com.fantasy.Intefaces;

public interface ITeam {
    String getName();
    void setName(String name);
}
