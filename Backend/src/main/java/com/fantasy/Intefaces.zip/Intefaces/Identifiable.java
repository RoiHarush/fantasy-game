package com.fantasy.Intefaces;

public interface Identifiable {

    int getId();
}
